import Foundation

enum RuntimeError: Error {
    case illegalState
    case nilPointer
}
